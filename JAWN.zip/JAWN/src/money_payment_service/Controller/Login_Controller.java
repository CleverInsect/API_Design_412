package money_payment_service.Controller;

import money_payment_service.Model.User;

import javax.swing.text.View;

public class Login_Controller {

    private User user;
    private View view;

    public Login_Controller(User user, View view) {
        this.user = user;
        this.view = view;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public View getView() {
        return view;
    }

    public void setView(View view) {
        this.view = view;
    }
}
