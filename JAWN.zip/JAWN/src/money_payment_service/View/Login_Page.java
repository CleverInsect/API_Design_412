package money_payment_service.View;

public class Login_Page {

    public void loginDisplay(){
        //this method will display the login box
    }
}
